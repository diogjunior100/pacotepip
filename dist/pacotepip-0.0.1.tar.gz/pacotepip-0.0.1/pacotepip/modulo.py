for i in range(10):
    print("Seu pacote pip está funcionando\n");